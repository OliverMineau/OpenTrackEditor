package com.minapps.trackeditor.feature_track_export____.presentation.util

import com.minapps.trackeditor.core.domain.model.Track

interface GpxExporterItf {
    fun export(track: Track): String
}
