package com.minapps.trackeditor.feature_track_export____.domain.usecase

import com.minapps.trackeditor.core.domain.model.Track
import com.minapps.trackeditor.feature_track_export____.domain.repository.TrackExportRepository


class ExportTrackUseCase(private val repo: TrackExportRepository) {

    fun toGpx(track: Track): String = repo.exportToGpx(track)

}