package com.minapps.trackeditor.feature_track_export____.presentation.util

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

object ExportFileHelper {

    fun saveExportedFile(context: Context, fileName: String, content: String): File {
        val exportDir = context.getExternalFilesDir(null) ?: context.filesDir
        val file = File(exportDir, fileName)
        file.writeText(content, Charsets.UTF_8)
        return file
    }

    fun shareFile(context: Context, file: File, mimeType: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share track"))
    }

    fun showSaveFileDialog(context: Context, onFileNameEntered: (String) -> Unit) {
        val input = EditText(context).apply {
            hint = "Enter file name (without extension)"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        AlertDialog.Builder(context)
            .setTitle("Save Track")
            .setMessage("Enter the file name")
            .setView(input)
            .setPositiveButton("Save") { dialog, _ ->
                val fileName = input.text.toString().trim()
                if (fileName.isNotEmpty()) {
                    // Append extension here, e.g. ".gpx"
                    onFileNameEntered("$fileName.gpx")
                } else {
                    Toast.makeText(context, "File name cannot be empty", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.cancel() }
            .show()
    }

}
