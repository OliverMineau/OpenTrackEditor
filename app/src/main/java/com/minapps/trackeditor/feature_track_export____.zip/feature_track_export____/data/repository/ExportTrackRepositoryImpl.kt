package com.minapps.trackeditor.feature_track_export____.data.repository

import android.content.Context
import android.net.Uri
import com.minapps.trackeditor.core.domain.repository.ExportTrackRepositoryItf
import com.minapps.trackeditor.feature_track_export____.presentation.util.ExportFileHelper.saveExportedFile
import java.io.File
import javax.inject.Inject

class ExportTrackRepositoryImpl @Inject constructor(
    private val context: Context
) : ExportTrackRepositoryItf {

    override suspend fun exportTrack(
        trackId: Int,
        fileName: String
    ): Uri? {
        TODO("Not yet implemented")
    }

    override suspend fun saveTrackAsFile(fileName: String, content: String, context: Context): File {
        return saveExportedFile(context, fileName, content)
    }
}
