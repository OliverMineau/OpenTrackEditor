package com.minapps.trackeditor.feature_track_export____.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

object FileExporter {

    /**
     * Saves text to a public directory (Downloads by default)
     * and returns a content Uri for sharing.
     *
     * @param fileName Name of file with extension (e.g. "track.gpx")
     * @param text Text content to save (GPX or KML)
     * @return Uri for the saved file (for sharing)
     */
    fun saveTextAndGetUri(context: Context, fileName: String, text: String): Uri {
        // Choose public directory
        val downloadsFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

        if (!downloadsFolder.exists()) {
            downloadsFolder.mkdirs()  // Create if not exists
        }

        val file = File(downloadsFolder, fileName)
        FileOutputStream(file).use { stream ->
            stream.write(text.toByteArray())
        }

        // Get URI via FileProvider (must match provider_authority and xml/file_paths)
        return FileProvider.getUriForFile(
            context,
            "com.minapps.trackeditor.fileprovider",  // Your authority in manifest
            file
        )
    }

    fun shareFile(context: Context, fileUri: Uri, mimeType: String) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, fileUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(
            Intent.createChooser(shareIntent, "Share track")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

}
