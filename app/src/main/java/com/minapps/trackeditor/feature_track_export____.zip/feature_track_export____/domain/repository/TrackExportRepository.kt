package com.minapps.trackeditor.feature_track_export____.domain.repository

import com.minapps.trackeditor.core.domain.model.Track

interface TrackExportRepository {
    fun exportToGpx(track: Track): String
    //fun exportToKml(track: Track): String
}
