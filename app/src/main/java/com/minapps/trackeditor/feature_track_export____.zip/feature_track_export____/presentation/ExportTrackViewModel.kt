package com.minapps.trackeditor.feature_track_export____.presentation

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.minapps.trackeditor.core.domain.model.Track
import com.minapps.trackeditor.feature_track_export____.presentation.util.ExportFileHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ExportTrackViewModel(
    //private val exportTrackUseCase: ExportTrackUseCase
) : ViewModel() {

    /*enum class Format { GPX, KML }

    fun exportTrack(context: Context, track: Track, format: Format) {
        viewModelScope.launch(Dispatchers.IO) {
            val fileName: String
            val content: String
            val mimeType: String

            when (format) {
                Format.GPX -> {
                    content = exportTrackUseCase.toGpx(track)
                    fileName = "${track.name?: "track"}.gpx"
                    mimeType = "application/gpx+xml"
                }
                Format.KML -> {
                    content = exportTrackUseCase.toGpx(track)//exportTrackUseCase.toKml(track)
                    fileName = "${track.name ?: "track"}.kml"
                    mimeType = "application/vnd.google-earth.kml+xml"
                }
            }

            val file = ExportFileHelper.saveExportedFile(context, fileName, content)

            // Switch to main thread to start share intent
            launch(Dispatchers.Main) {
                ExportFileHelper.shareFile(context, file, mimeType)
            }
        }
    }*/
}